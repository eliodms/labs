﻿###################################################
# This script is called by Install-SQL.ps1 script #
###################################################

# Load functions
$ScriptDir = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
. (Join-Path $ScriptDir "Functions.ps1")

# Install WSFC feature (even if already installed, doesn't harm to reinstall it)
Write-Log -Message "Installing Failover Cluster feature."
Install-WindowsFeature -Name Failover-Clustering -IncludeManagementTools

# Define SQL Server data directories
$SqlDirs = @(
    "D:\SQL\Data",
    "L:\SQL\Logs",
    "L:\SQL\Temp",
    "D:\SQL\Backup"
)

Write-Log -Message "Path to be used for SQL install: #$SqlDirs"

# Create each SQL data directory if needed
foreach ($dir in $SqlDirs) {
    if (-not (Test-Path $dir)) {
        New-Item -Path $dir -ItemType Directory -Force | Out-Null
        Write-Log -Message "Created directory: $dir"
    } else {
        Write-Log -Message "Directory already exists: $dir"
    }
}

# Validate paths
if (-not (Test-Path $SetupExe)) {
    Write-Log -Message "setup.exe not found at: $SetupExe"
    exit 1
}
if (-not (Test-Path $ConfigFile)) {
    Write-Log -Message "Configuration file not found at: $ConfigFile"
    exit 1
}

# Build SQL setup arguments
$Arguments = @(
    "/ConfigurationFile=`"$ConfigFile`""
) -join ' '

## $Arguments = @(
##     "/ConfigurationFile=`"$ConfigFile`"",
##     "/LogPath=`"$logSubFolder`""
## ) -join ' '

# Run the SQL Server setup process
Write-Log -Message "Launching SQL Server setup..."

Write-Log -Message "Debug"
Write-Log -Message "SetupExe: $SetupExe"
Write-Log -Message "ArgumentList: $Arguments"
Write-Log -Message "Command-line:"
Write-Log -Message "Start-Process -FilePath $SetupExe -ArgumentList $Arguments -Wait -NoNewWindow"
# Write-Log -Message "What comes after this row is pure SQL logging"
# Write-Log -Message "*********** SQL setup logging:"
# Start-Process -FilePath $SetupExe -ArgumentList $Arguments -Wait -NoNewWindow

Write-Log -Message "Check SQLStandardOutput.log for standard SQL setup output"
Write-Log -Message "Check SQLStandardError.log for standard SQL setup error"

Start-Process -FilePath $SetupExe `
    -ArgumentList $Arguments `
    -RedirectStandardOutput $RedirectSQLStandardOutput `
    -RedirectStandardError $RedirectSQLStandardError `
    -Wait `
    -NoNewWindow

# Write-Log -Message "*********** End of SQL setup logging:"

## NEVER END while (-not (Get-Service -Name MSSQLSERVER -ErrorAction SilentlyContinue)) {
## NEVER END     Write-Log -Message "Waiting for MSSQLSERVER service running - sleeping 10s"
## NEVER END     Start-Sleep -Seconds 10
## NEVER END }

Write-Log -Message "SQL Server setup completed and running."

