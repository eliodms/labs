﻿<#
.SYNOPSIS
    Delegate rights in an OU or container (e.g., CN=Computers) so a user/group can create a Failover Cluster CNO
    and optionally manage computer objects (VCO lifecycle).

.DESCRIPTION
    Works with either OU=... or CN=... distinguished names (any directory object that can hold computer objects).
    -Minimal:       CreateChild (computer) on the target object (enough for CNO creation)
    -Recommended:   CreateChild/DeleteChild (computer) + GenericAll on descendant computer objects

.PARAMETER OuDN
    Distinguished Name of target directory object (OU=... or CN=...)

.PARAMETER Identity
    User or group to delegate to (e.g., 'corp\user01')

.PARAMETER Minimal
    Minimal rights (Create Child [computer] only)

.PARAMETER Recommended
    Recommended rights (Create/Delete Child [computer] + GenericAll on descendant computer objects)

.EXAMPLES
    .\Delegate-ClusterOuRights.ps1 -OuDN "CN=Computers,DC=corp,DC=demolab,DC=com" -Identity "corp\user01" -Recommended
    .\Delegate-ClusterOuRights.ps1 -OuDN "OU=Servers,DC=corp,DC=demolab,DC=com"    -Identity "corp\ClusterAdmins" -Minimal -WhatIf

.NOTES
    - Run with an account that can modify the ACL on the target OU/container.
    - Idempotent: re-running will not create duplicate ACEs.
    - Supports -WhatIf and -Confirm.
#>

[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
param(
    [Parameter(Mandatory = $true)]
    [string]$OuDN,

    [Parameter(Mandatory = $true)]
    [string]$Identity,

    [switch]$Minimal,
    [switch]$Recommended
)

function Throw-Error($Message) { throw [System.Exception]::new($Message) }

# Bind to the directory object (OU or container) and validate DN
try {
    $entry = New-Object System.DirectoryServices.DirectoryEntry("LDAP://$OuDN")
    $null = $entry.NativeObject  # force bind to fail early if DN is wrong or inaccessible
} catch {
    Throw-Error "Directory object not found or not accessible: '$OuDN'. $_"
}

# Resolve the identity to a SID
try {
    $nt  = New-Object System.Security.Principal.NTAccount($Identity)
    $sid = $nt.Translate([System.Security.Principal.SecurityIdentifier])
} catch {
    Throw-Error "Failed to resolve identity '$Identity' to a SID. $_"
}

# Default to -Recommended if user didn't choose exactly one
if (-not ($Minimal -xor $Recommended)) {
    Write-Warning "Choose exactly one of -Minimal or -Recommended. Defaulting to -Recommended."
    $Recommended = $true
    $Minimal = $false
}

# Resolve the schema GUID for the 'computer' class (no hardcoding)
try {
    $schema  = [System.DirectoryServices.ActiveDirectory.ActiveDirectorySchema]::GetCurrentSchema()
    $compCls = $schema.FindClass("computer")
    $ComputerClassGuid = $compCls.SchemaGuid
} catch {
    Throw-Error "Could not resolve schema GUID for 'computer'. $_"
}

function Test-AceExists {
    param(
        [System.DirectoryServices.ActiveDirectorySecurity]$Acl,
        [System.Security.Principal.SecurityIdentifier]$Sid,
        [System.DirectoryServices.ActiveDirectoryRights]$Rights,
        [System.DirectoryServices.ActiveDirectorySecurityInheritance]$Inheritance,
        [Guid]$ObjectTypeGuid,
        [Guid]$InheritedObjectTypeGuid
    )
    foreach ($ace in $Acl.GetAccessRules($true, $true, [System.Security.Principal.SecurityIdentifier])) {
        if ($ace.IdentityReference -eq $Sid -and
            $ace.AccessControlType -eq [System.Security.AccessControl.AccessControlType]::Allow -and
            # Ensure the ACE includes at least the requested flags
            (($ace.ActiveDirectoryRights -band $Rights) -eq $Rights) -and
            $ace.InheritanceType -eq $Inheritance -and
            $ace.ObjectType -eq $ObjectTypeGuid -and
            $ace.InheritedObjectType -eq $InheritedObjectTypeGuid) {
            return $true
        }
    }
    return $false
}

function Add-Ace {
    param(
        [System.DirectoryServices.DirectoryEntry]$Entry,
        [System.Security.Principal.SecurityIdentifier]$Sid,
        [System.DirectoryServices.ActiveDirectoryRights]$Rights,
        [System.Security.AccessControl.AccessControlType]$Type,
        [System.DirectoryServices.ActiveDirectorySecurityInheritance]$Inheritance,
        [Guid]$ObjectTypeGuid,
        [Guid]$InheritedObjectTypeGuid,
        [string]$Note
    )
    $acl = $Entry.ObjectSecurity
    if (Test-AceExists -Acl $acl -Sid $Sid -Rights $Rights -Inheritance $Inheritance -ObjectTypeGuid $ObjectTypeGuid -InheritedObjectTypeGuid $InheritedObjectTypeGuid) {
        Write-Host "Unchanged (already present): $Note"
        return $false
    }
    $rule = New-Object System.DirectoryServices.ActiveDirectoryAccessRule(
        $Sid,
        $Rights,
        $Type,
        $ObjectTypeGuid,
        $Inheritance,
        $InheritedObjectTypeGuid
    )
    $acl.AddAccessRule($rule)
    $Entry.ObjectSecurity = $acl
    Write-Host "Added: $Note"
    return $true
}

Write-Host "Target DN : $OuDN"
Write-Host "Delegate  : $Identity ($sid)"
Write-Host "Mode      : " -NoNewline
if ($Minimal) { Write-Host "Minimal" } else { Write-Host "Recommended" }

# Build intended ACEs
$intended = @()
if ($Minimal) {
    $intended += [pscustomobject]@{
        Rights   = [System.DirectoryServices.ActiveDirectoryRights]::CreateChild
        Type     = [System.Security.AccessControl.AccessControlType]::Allow
        Inherit  = [System.DirectoryServices.ActiveDirectorySecurityInheritance]::None
        ObjType  = $ComputerClassGuid
        InhType  = [Guid]::Empty
        Note     = "Allow CREATE Computer objects in this OU/container"
    }
}
if ($Recommended) {
    $intended +=
    [pscustomobject]@{
        Rights   = [System.DirectoryServices.ActiveDirectoryRights]::CreateChild
        Type     = [System.Security.AccessControl.AccessControlType]::Allow
        Inherit  = [System.DirectoryServices.ActiveDirectorySecurityInheritance]::None
        ObjType  = $ComputerClassGuid
        InhType  = [Guid]::Empty
        Note     = "Allow CREATE Computer objects in this OU/container"
    },
    [pscustomobject]@{
        Rights   = [System.DirectoryServices.ActiveDirectoryRights]::DeleteChild
        Type     = [System.Security.AccessControl.AccessControlType]::Allow
        Inherit  = [System.DirectoryServices.ActiveDirectorySecurityInheritance]::None
        ObjType  = $ComputerClassGuid
        InhType  = [Guid]::Empty
        Note     = "Allow DELETE Computer objects in this OU/container"
    },
    [pscustomobject]@{
        Rights   = [System.DirectoryServices.ActiveDirectoryRights]::GenericAll
        Type     = [System.Security.AccessControl.AccessControlType]::Allow
        Inherit  = [System.DirectoryServices.ActiveDirectorySecurityInheritance]::Descendents
        ObjType  = [Guid]::Empty
        InhType  = $ComputerClassGuid
        Note     = "Full control on descendant Computer objects"
    }
}

# Apply ACEs
$changes = 0
foreach ($ace in $intended) {
    if ($PSCmdlet.ShouldProcess($OuDN, "Add ACE: $($ace.Note)")) {
        $added = Add-Ace -Entry $entry `
            -Sid $sid `
            -Rights $ace.Rights `
            -Type $ace.Type `
            -Inheritance $ace.Inherit `
            -ObjectTypeGuid $ace.ObjType `
            -InheritedObjectTypeGuid $ace.InhType `
            -Note $ace.Note

        if ($added) { $changes++ }
    }
}

# Persist changes unless -WhatIf
if ($changes -gt 0 -and -not $WhatIfPreference) {
    try {
        $entry.CommitChanges()
        Write-Host "ACLs updated on $OuDN."
    } catch {
        Throw-Error "Failed to write ACL changes. $_"
    }
} else {
    if ($WhatIfPreference) {
        Write-Host "WhatIf: No changes committed."
    } else {
        Write-Host "No changes were necessary."
    }
}

Write-Host "`nVerify with:"
Write-Host "  dsacls `"$OuDN`" | findstr /i `"$($Identity.Split('\')[-1])`""

# Attention: not double quote if script is asking for value

# Usage .\Delegate-ClusterOuRights.ps1 `
# Usage   -OuDN "CN=Computers,DC=corp,DC=demolab,DC=com" `
# Usage   -Identity "corp\user01" `
# Usage   -Recommended

dsacls "CN=Computers,DC=corp,DC=demolab,DC=com" | findstr /i "user01"

# Verify # Or in PowerShell:
# Verify $de  = [ADSI]"LDAP://CN=Computers,DC=corp,DC=demolab,DC=com"
# Verify $acl = $de.ObjectSecurity
# Verify $acl.GetAccessRules($true,$true,[System.Security.Principal.NTAccount]) |
# Verify   Where-Object { $_.IdentityReference -like "*corp\user01" } |
# Verify   Select IdentityReference, ActiveDirectoryRights, InheritanceType, ObjectType, InheritedObjectType