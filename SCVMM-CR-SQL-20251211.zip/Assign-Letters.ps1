﻿###################################################
# This script is called by Install-SQL.ps1 script #
###################################################

# Load functions
$ScriptDir = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
. (Join-Path $ScriptDir "Functions.ps1")

$cdrom = Get-CimInstance -ClassName Win32_Volume | Where-Object { $_.DriveType -eq 5 }

if ($cdrom) {
    $usedLetters = Get-Volume | Where-Object { $_.DriveLetter } | Select-Object -ExpandProperty DriveLetter
    if ($usedLetters -contains 'Z') {
        Write-Log -Message "Drive letter Z is already in use. Skipping CD-ROM reassignment."
    } else {
        Set-CimInstance -InputObject $cdrom -Property @{DriveLetter = 'Z:'}
        Write-Log -Message "CD-ROM drive letter changed to Z:"
    }
} else {
    Write-Log -Message "No CD-ROM drive found."
}

function Assign-DriveLetter {
    param (
        [int]$DiskNumber,
        [int]$PartitionNumber,
        [string]$DesiredLetter
    )

    Write-Log -Message "Attempting WMI assignment of drive letter ${DesiredLetter} to disk ${DiskNumber}, partition ${PartitionNumber}"

    # Check if the desired letter is already in use
    $usedLetters = Get-Volume | Where-Object { $_.DriveLetter } | Select-Object -ExpandProperty DriveLetter
    if ($usedLetters -contains $DesiredLetter) {
        Write-Log -Message "Drive letter ${DesiredLetter} is already in use. Skipping assignment."
        return
    }

    # Try WMI assignment based on volume label
    $volume = Get-CimInstance -ClassName Win32_Volume | Where-Object { $_.Label -eq "${DesiredLetter}-drive" }

    if ($volume) {
        try {
            Set-CimInstance -InputObject $volume -Property @{DriveLetter = "${DesiredLetter}:"}
            Write-Log -Message "WMI assignment succeeded: ${DesiredLetter} assigned to volume labeled '$($volume.Label)'"
        } catch {
            Write-Log -Message "WMI assignment failed for ${DesiredLetter}: $_"
        }
    } else {
        Write-Log -Message "No matching volume found for WMI assignment to ${DesiredLetter}"
    }
}

# Get all disks
$disks = Get-Disk

foreach ($disk in $disks) {
    # Bring disk online if offline
    Write-Log -Message "Inspecting disk $($disk.Number)"
    if ($disk.IsOffline) {
        try {
            Set-Disk -Number $disk.Number -IsOffline $false
            Write-Log -Message "Disk $($disk.Number) brought online."
        } catch {
            Write-Log -Message "Failed to bring Disk $($disk.Number) online: $_"
            continue
        }
    }

    # Remove read-only flag if set
    if ($disk.IsReadOnly) {
        try {
            Set-Disk -Number $disk.Number -IsReadOnly $false
            Write-Log -Message "Disk $($disk.Number) set to writable."
        } catch {
            Write-Log -Message "Failed to clear read-only on Disk $($disk.Number): $_"
            continue
        }
    }

    # Get partitions without drive letters
    $partitions = Get-Partition -DiskNumber $disk.Number # | Where-Object { -not $_.DriveLetter -and $_.Type -eq 'Basic' -and $_.Size -gt 1GB }

    foreach ($partition in $partitions) {
        Write-Log -Message "Inspecting disk $($disk.Number) partition $($partition.PartitionNumber)"
        try {
            $volume = Get-Volume -Partition $partition -ErrorAction SilentlyContinue
            if ($null -eq $volume) {
                Write-Log -Message "Volume not found for Disk $($disk.Number), Partition $($partition.PartitionNumber)"
                continue
            }

            switch ($volume.FileSystemLabel.Trim()) {
                'D-drive' {
                    Write-Log -Message "Found volume label '$($volume.FileSystemLabel)', assigning it to D drive"
                    Assign-DriveLetter -DiskNumber $disk.Number -PartitionNumber $partition.PartitionNumber -DesiredLetter 'D'
                    break
                }
                'L-drive' {
                    Write-Log -Message "Found volume label '$($volume.FileSystemLabel)', assigning it to L drive"
                    Assign-DriveLetter -DiskNumber $disk.Number -PartitionNumber $partition.PartitionNumber -DesiredLetter 'L'
                    break
                }
                default {
                    Write-Log -Message "Volume label '$($volume.FileSystemLabel)' does not match expected labels."
                }
            }
        } catch {
            Write-Log -Message "Error processing Disk $($disk.Number), Partition $($partition.PartitionNumber): $_"
        }
    }
}

