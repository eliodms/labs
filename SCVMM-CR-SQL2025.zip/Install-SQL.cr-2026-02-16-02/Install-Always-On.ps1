﻿######################################################################
# This script is called by Install-SQL.ps1 script
######################################################################
param (
    [Parameter(Mandatory = $true)]
    [string]$WSFC_Name,
    [Parameter(Mandatory = $true)]
    [string]$WSFC_IP,
    [Parameter(Mandatory = $true)]
    [string]$PrimarySQLName,
    [Parameter(Mandatory = $true)]
    [string]$SecondarySQLName,
    [Parameter(Mandatory = $true)]
    [string]$DBName,
    [Parameter(Mandatory = $true)]
    [string]$BackupPath,
    [Parameter(Mandatory = $true)]
    [string]$AG_Name,
    [Parameter(Mandatory = $true)]
    [string]$ListenerName,
    [Parameter(Mandatory = $true)]
    [string]$ListenerIP,
    [Parameter(Mandatory = $true)]
    [string]$ListenerSM,
    [Parameter(Mandatory = $true)]
    [string]$ListenerPort,
    [Parameter(Mandatory = $true)]
    [string]$SQLAccount
)

# Load functions
$ScriptDir = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
. (Join-Path $ScriptDir "Functions.ps1")

# Import SQLPS (SQL 2025 = 170)
Import-Module "C:\Program Files\Microsoft SQL Server\170\Tools\PowerShell\Modules\SQLPS\SQLPS.psd1" -DisableNameChecking
# Failover Clustering cmdlets
Import-Module FailoverClusters -ErrorAction Stop

######################################################################
# Firewall rules
######################################################################
$ports = @(1433, 1434, 5022, 135)
foreach ($port in $ports) {
    $ruleExists = Get-NetFirewallRule -Enabled True -Direction Inbound `
        | Where-Object {
            (($_ | Get-NetFirewallPortFilter).LocalPort -contains $Port) -and
            (($_ | Get-NetFirewallPortFilter).Protocol -eq "TCP")
        }
    if ($ruleExists) {
        Write-Log -Message "Port $Port (TCP) is already allowed in the firewall."
    }
    else {
        Write-Log -Message "Port $Port (TCP) is not open. Creating inbound rule..."
        New-NetFirewallRule -DisplayName "Allow SQL Port $port" -Direction Inbound -LocalPort $port -Protocol TCP -Action Allow
        Write-Log -Message "Inbound rule created. Port $Port (TCP) is now open."
    }
}

######################################################################
# Cluster readiness helpers
######################################################################
function Wait-ClusterReady {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$ClusterName,
        [int]$TimeoutSeconds = 1800,
        [int]$PollSeconds = 10
    )
    Write-Log -Message ("Waiting for WSFC cluster '{0}' to be created and stabilized (timeout {1}s)..." -f $ClusterName, $TimeoutSeconds)
    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    while ((Get-Date) -lt $deadline) {
        $cl = Get-Cluster -Name $ClusterName -ErrorAction SilentlyContinue
        if ($null -eq $cl) {
            Start-Sleep -Seconds $PollSeconds
            continue
        }
        $nodes = Get-ClusterNode -Cluster $ClusterName -ErrorAction SilentlyContinue
        $nodeStatesOk = ($nodes -and (($nodes | Where-Object { $_.State -eq 'Up' }).Count -ge 2))
        $coreGroup = Get-ClusterGroup -Cluster $ClusterName -Name 'Cluster Group' -ErrorAction SilentlyContinue
        $coreGroupOnline = ($coreGroup -and $coreGroup.State -eq 'Online')
        $clusterNameRes = Get-ClusterResource -Cluster $ClusterName -Name 'Cluster Name' -ErrorAction SilentlyContinue
        $clusterNameOnline = ($clusterNameRes -and $clusterNameRes.State -eq 'Online')
        if ($nodeStatesOk -and $coreGroupOnline -and $clusterNameOnline) {
            $nodeNames = $nodes | Select-Object -ExpandProperty Name
            Write-Log -Message ("WSFC '{0}' is READY. Nodes: {1}" -f $ClusterName, ($nodeNames -join ', '))
            return $true
        }
        Write-Log -Message ("WSFC not ready yet: NodesUp={0} CoreGroupOnline={1} ClusterNameOnline={2}" -f $nodeStatesOk, $coreGroupOnline, $clusterNameOnline)
        Start-Sleep -Seconds $PollSeconds
    }
    return $false
}

function Ensure-ClusSvcRunning {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string[]]$Nodes,
        [int]$TimeoutSeconds = 600,
        [int]$PollSeconds = 5
    )
    foreach ($n in $Nodes) {
        Write-Log -Message ("Ensuring Cluster Service (clussvc) is RUNNING on [{0}]..." -f $n)
        $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
        while ((Get-Date) -lt $deadline) {
            try {
                $svc = Get-CimInstance -ClassName Win32_Service -ComputerName $n -Filter "Name='clussvc'" -ErrorAction Stop
                if ($svc.State -eq "Running") {
                    Write-Log -Message ("clussvc is RUNNING on [{0}]." -f $n)
                    break
                }
                Write-Log -Message ("clussvc state on [{0}] is [{1}] - attempting StartService..." -f $n, $svc.State)
                Invoke-CimMethod -ClassName Win32_Service -ComputerName $n -Filter "Name='clussvc'" -MethodName StartService -ErrorAction Stop | Out-Null
            }
            catch {
                Write-Log -Message ("Failed while ensuring clussvc on [{0}]: {1}" -f $n, $_.Exception.Message)
            }
            Start-Sleep -Seconds $PollSeconds
        }
        $svc2 = Get-CimInstance -ClassName Win32_Service -ComputerName $n -Filter "Name='clussvc'" -ErrorAction Stop
        if ($svc2.State -ne "Running") {
            throw ("Timeout ensuring clussvc RUNNING on [{0}]. Final state: {1}" -f $n, $svc2.State)
        }
    }
}

######################################################################
# Always On enablement - LOCAL (DEFAULT instance) + wait remote status
######################################################################
function Ensure-AlwaysOn-EnabledLocal {
    [CmdletBinding()]
    param(
        [string]$InstanceName = "DEFAULT"
    )
    $serverInstance = if ($InstanceName -eq "DEFAULT") { "localhost" } else { "localhost\$InstanceName" }
    $serverPath = "SQLSERVER:\SQL\localhost\$InstanceName"
    # Wait local SQL connectivity
    $maxRetries = 60
    $retrySeconds = 5
    for ($i = 1; $i -le $maxRetries; $i++) {
        try {
            Invoke-Sqlcmd -ServerInstance $serverInstance -Query "SELECT 1" -ErrorAction Stop | Out-Null
            break
        }
        catch {
            Write-Log -Message ("Local SQL not ready on [{0}] Attempt {1}/{2} : {3}" -f $serverInstance, $i, $maxRetries, $_.Exception.Message)
            Start-Sleep -Seconds $retrySeconds
        }
    }
    # Check HADR
    $result = Invoke-Sqlcmd -ServerInstance $serverInstance -Query "SELECT SERVERPROPERTY('IsHadrEnabled') AS IsHadrEnabled" -ErrorAction Stop
    if ($result.IsHadrEnabled -eq 1) {
        Write-Log -Message ("Always On is already ENABLED locally on [{0}]." -f $serverInstance)
        return
    }
    Write-Log -Message ("Enabling Always On locally on [{0}]..." -f $serverInstance)
    Enable-SqlAlwaysOn -Path $serverPath -Force
    # Restart SQL service locally
    $serviceName = if ($InstanceName -eq "DEFAULT") { "MSSQLSERVER" } else { "MSSQL`$$InstanceName" }
    Write-Log -Message ("Restarting local SQL service [{0}]..." -f $serviceName)
    Restart-Service -Name $serviceName -Force -ErrorAction Stop
    # Wait back online
    for ($i = 1; $i -le $maxRetries; $i++) {
        try {
            Invoke-Sqlcmd -ServerInstance $serverInstance -Query "SELECT 1" -ErrorAction Stop | Out-Null
            break
        }
        catch {
            Write-Log -Message ("SQL after restart not ready on [{0}] Attempt {1}/{2} : {3}" -f $serverInstance, $i, $maxRetries, $_.Exception.Message)
            Start-Sleep -Seconds $retrySeconds
        }
    }
    $result2 = Invoke-Sqlcmd -ServerInstance $serverInstance -Query "SELECT SERVERPROPERTY('IsHadrEnabled') AS IsHadrEnabled" -ErrorAction Stop
    if ($result2.IsHadrEnabled -ne 1) {
        throw ("Enable-SqlAlwaysOn executed but IsHadrEnabled={0} locally on [{1}]." -f $result2.IsHadrEnabled, $serverInstance)
    }
    Write-Log -Message ("Always On ENABLED locally on [{0}]." -f $serverInstance)
}

function Wait-RemoteHadrEnabled {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$ServerInstance,
        [int]$TimeoutSeconds = 1800,
        [int]$PollSeconds = 10
    )
    Write-Log -Message ("Waiting for [{0}] to report IsHadrEnabled=1 (timeout {1}s)..." -f $ServerInstance, $TimeoutSeconds)
    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    while ((Get-Date) -lt $deadline) {
        try {
            $r = Invoke-Sqlcmd -ServerInstance $ServerInstance -Query "SELECT SERVERPROPERTY('IsHadrEnabled') AS IsHadrEnabled" -ErrorAction Stop
            if ($r.IsHadrEnabled -eq 1) {
                Write-Log -Message ("[{0}] reports IsHadrEnabled=1." -f $ServerInstance)
                return $true
            }
            Write-Log -Message ("[{0}] IsHadrEnabled={1}. Waiting..." -f $ServerInstance, $r.IsHadrEnabled)
        }
        catch {
            Write-Log -Message ("Invoke-Sqlcmd to [{0}] failed while waiting HADR: {1}" -f $ServerInstance, $_.Exception.Message)
        }
        Start-Sleep -Seconds $PollSeconds
    }
    return $false
}

# --- BEGIN: WSFC-in-SQL readiness gate (minimal, inline) ---
function Test-SqlSeesWsfcUp {
    param([Parameter(Mandatory=$true)][string]$ServerInstance)
    try {
        $q = @"
SELECT
  SeesWsfc = CASE WHEN EXISTS (SELECT 1 FROM sys.dm_hadr_cluster) THEN 1 ELSE 0 END,
  MyMemberState = (SELECT TOP (1) member_state_desc
                   FROM sys.dm_hadr_cluster_members
                   WHERE member_name = CAST(SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS nvarchar(128)))
"@
        $r = Invoke-Sqlcmd -ServerInstance $ServerInstance -Query $q -ErrorAction Stop
        return ($r.SeesWsfc -eq 1 -and $r.MyMemberState -eq 'UP')
    } catch {
        return $false
    }
}

function Wait-SqlWsfcBound {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$PrimaryInstance,
        [Parameter(Mandatory=$true)][string]$SecondaryInstance,
        [int]$TimeoutSeconds = 600,
        [int]$PollSeconds = 5
    )
    Write-Log -Message ("Waiting for SQL instances to bind to WSFC (timeout {0}s)..." -f $TimeoutSeconds)
    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    while ((Get-Date) -lt $deadline) {
        $pOk = Test-SqlSeesWsfcUp -ServerInstance $PrimaryInstance
        $sOk = Test-SqlSeesWsfcUp -ServerInstance $SecondaryInstance
        Write-Log -Message ("WSFC binding: Primary={0}, Secondary={1}" -f $pOk, $sOk)
        if ($pOk -and $sOk) { return $true }
        Start-Sleep -Seconds $PollSeconds
    }
    return $false
}
# --- END: WSFC-in-SQL readiness gate ---

######################################################################
# Secondary node behavior:
# - wait for cluster READY
# - enable AlwaysOn locally
# - exit (do not attempt AG creation)
######################################################################
if ($Env:COMPUTERNAME -ne $PrimarySQLName) {
    Write-Log -Message ("This node ({0}) is not the primary SQL node." -f $Env:COMPUTERNAME)
    Write-Log -Message ("Primary node is ({0}). Waiting for cluster '{1}' to be READY before enabling AlwaysOn locally..." -f $PrimarySQLName, $WSFC_Name)
    $ok = Wait-ClusterReady -ClusterName $WSFC_Name -TimeoutSeconds 1800 -PollSeconds 10
    if (-not $ok) {
        Write-Log -Message ("Timeout: cluster '{0}' did not become READY." -f $WSFC_Name)
        exit 1
    }
    Ensure-AlwaysOn-EnabledLocal -InstanceName "DEFAULT"
    Write-Log -Message "Secondary node completed local Always On enablement. Exiting Install-Always-On.ps1."
    exit 0
}

######################################################################
# Primary node behavior:
# - create cluster if missing + wait READY
# - enable AlwaysOn locally
# - wait secondary HADR enabled
# - proceed with AG + Listener
######################################################################
Write-Log -Message "This is the primary SQL node. Proceeding with cluster creation and Always On configuration..."
# --- Pre-check: ensure Secondary node is reachable 5 times in a row (up to 15 minutes total) ---
$maxAttempts = 15
$intervalSeconds = 60
$consecutiveNeeded = 5
$attempt = 0
$consecutiveSuccess = 0
Write-Log -Message ("Waiting for {0} to be reachable ({1} consecutive minutes, up to {2} total)..." -f $SecondarySQLName, $consecutiveNeeded, $maxAttempts)
while ($attempt -lt $maxAttempts -and $consecutiveSuccess -lt $consecutiveNeeded) {
    $attempt++
    $reachable = Test-Connection -ComputerName $SecondarySQLName -Count 1 -Quiet -ErrorAction SilentlyContinue
    if ($reachable) {
        $consecutiveSuccess++
        Write-Log -Message ("[{0}] reachable ({1}/{2} consecutive)." -f $SecondarySQLName, $consecutiveSuccess, $consecutiveNeeded)
    }
    else {
        $consecutiveSuccess = 0
        Write-Log -Message ("[{0}] not reachable. Consecutive counter reset." -f $SecondarySQLName)
    }
    if ($consecutiveSuccess -lt $consecutiveNeeded) {
        Start-Sleep -Seconds $intervalSeconds
    }
}
if ($consecutiveSuccess -lt $consecutiveNeeded) {
    Write-Log -Message ("Secondary node '{0}' did not remain reachable. Aborting." -f $SecondarySQLName)
    exit 1
}
Write-Log -Message ("Secondary node '{0}' confirmed reachable. Proceeding with cluster creation..." -f $SecondarySQLName)

# Create the cluster if not already present
if (-not (Get-Cluster -Name $WSFC_Name -ErrorAction SilentlyContinue)) {
    Write-Log -Message ("WSFC cluster {0} does not exist, creating it." -f $WSFC_Name)
    try {
        New-Cluster -Name $WSFC_Name -Node $PrimarySQLName, $SecondarySQLName -StaticAddress $WSFC_IP -NoStorage -ErrorAction Stop
        Write-Log -Message ("Cluster creation requested for '{0}'." -f $WSFC_Name)
    }
    catch {
        Write-Log -Message ("Cluster {0} creation failed: {1}" -f $WSFC_Name, $_.Exception.Message)
        exit 1
    }
}
else {
    Write-Log -Message ("WSFC cluster {0} is already installed." -f $WSFC_Name)
}

# Wait cluster READY
$ok = Wait-ClusterReady -ClusterName $WSFC_Name -TimeoutSeconds 1800 -PollSeconds 10
if (-not $ok) {
    Write-Log -Message ("Timeout: cluster '{0}' did not become READY." -f $WSFC_Name)
    exit 1
}
# Make sure clussvc is RUNNING on both nodes before AG work (fixes 'replica manager waiting for WSFC')
Ensure-ClusSvcRunning -Nodes @($PrimarySQLName, $SecondarySQLName) -TimeoutSeconds 600 -PollSeconds 5

# NEW: ensure each SQL instance sees the WSFC and reports member_state_desc = UP
$bound = Wait-SqlWsfcBound -PrimaryInstance $PrimarySQLName -SecondaryInstance $SecondarySQLName -TimeoutSeconds 600 -PollSeconds 5
if (-not $bound) {
    Write-Log -Message "ERROR: SQL instances did not bind to WSFC in time. Aborting AG creation to avoid transient 'replica manager waiting for WSFC' failures."
    exit 1
}

######################################################################
# Original Ensure-Database (restored style) + add LOG backup safety
######################################################################
function Ensure-Database {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]$PrimarySQLName,
        [Parameter(Mandatory=$true)]
        [string]$DBName
    )
    Write-Log -Message "Fetching default backup path from SQL Server..."
    $defaultBackupPathQuery = @"
DECLARE @BackupPath NVARCHAR(512)
EXEC master.dbo.xp_instance_regread
N'HKEY_LOCAL_MACHINE',
N'Software\Microsoft\MSSQLServer\MSSQLServer',
N'BackupDirectory',
@BackupPath OUTPUT,
'no_output'
SELECT @BackupPath AS BackupPath
"@
    try {
        $backupPathResult = Invoke-Sqlcmd -ServerInstance $PrimarySQLName -Query $defaultBackupPathQuery -ErrorAction Stop
    }
    catch {
        Write-Log -Message "Failed to retrieve default backup path from SQL Server: $_"
        return
    }
    $defaultBackupPath = $backupPathResult.BackupPath
    if ([string]::IsNullOrEmpty($defaultBackupPath)) {
        Write-Log -Message "Could not retrieve default backup path from SQL Server. Please specify a backup path."
        return
    }
    Write-Log -Message "Using default backup path: $defaultBackupPath"

    # Check if database exists
    $dbExistsQuery = "SELECT COUNT(*) AS DBCount FROM sys.databases WHERE name = '$DBName'"
    try {
        $dbExistsResult = Invoke-Sqlcmd -ServerInstance $PrimarySQLName -Query $dbExistsQuery -ErrorAction Stop
    }
    catch {
        Write-Log -Message "Failed to check database existence: $_"
        return
    }
    $dbExists = $dbExistsResult.DBCount -gt 0
    if (-not $dbExists) {
        Write-Log -Message "Database '$DBName' does not exist on $PrimarySQLName. Creating database..."
        Invoke-Sqlcmd -ServerInstance $PrimarySQLName -Query "CREATE DATABASE [$DBName]"
        Write-Log -Message "Database '$DBName' created."
    }
    else {
        Write-Log -Message "Database '$DBName' exists on $PrimarySQLName."
    }

    # Ensure FULL recovery
    $recoveryModelQuery = "SELECT recovery_model_desc FROM sys.databases WHERE name = '$DBName'"
    try {
        $recoveryModelResult = Invoke-Sqlcmd -ServerInstance $PrimarySQLName -Query $recoveryModelQuery -ErrorAction Stop
    }
    catch {
        Write-Log -Message "Failed to get recovery model: $_"
        return
    }
    $recoveryModel = $recoveryModelResult.recovery_model_desc
    if ($recoveryModel -ne "FULL") {
        Write-Log -Message "Recovery model for '$DBName' is '$recoveryModel'. Changing to FULL..."
        Invoke-Sqlcmd -ServerInstance $PrimarySQLName -Query "ALTER DATABASE [$DBName] SET RECOVERY FULL"
        Write-Log -Message "Recovery model changed to FULL for '$DBName'."
    }
    else {
        Write-Log -Message "Recovery model for '$DBName' is already FULL."
    }

    # Check for recent FULL backup (last 1 day)
    $backupCheckQuery = @"
SELECT TOP 1 backup_finish_date
FROM msdb.dbo.backupset
WHERE database_name = '$DBName' AND type = 'D'
ORDER BY backup_finish_date DESC
"@
    $backupExists = $false
    $lastBackupDate = $null
    try {
        $backupResult = Invoke-Sqlcmd -ServerInstance $PrimarySQLName -Query $backupCheckQuery -ErrorAction Stop
        if ($backupResult) {
            $lastBackupDate = $backupResult.backup_finish_date
            $timeSinceBackup = (Get-Date) - $lastBackupDate
            if ($timeSinceBackup.TotalDays -lt 1) { $backupExists = $true }
        }
    }
    catch {
        Write-Log -Message "Failed to check backups: $_"
    }

    if (-not $backupExists) {
        Write-Log -Message "No recent full backup found for '$DBName'. Creating FULL backup..."
        $backupFile = Join-Path $defaultBackupPath "$DBName-FullBackup-$(Get-Date -Format 'yyyyMMddHHmmss').bak"
        $backupQuery = "BACKUP DATABASE [$DBName] TO DISK = N'$backupFile' WITH INIT, STATS = 10"
        try {
            Invoke-Sqlcmd -ServerInstance $PrimarySQLName -Query $backupQuery -ErrorAction Stop
            Write-Log -Message "FULL backup created at $backupFile."
        }
        catch {
            Write-Log -Message "FULL backup failed: $($_.Exception.Message)"
            throw
        }
    }
    else {
        Write-Log -Message "Recent full backup found for '$DBName' on $lastBackupDate."
    }

    # NEW: Take a LOG backup once to make DB joinable to AG (fixes 'bulk-logged changes / no log backup' errors)
    try {
        Write-Log -Message "Creating LOG backup for '$DBName' to establish log chain for AG join..."
        $logBackupFile = Join-Path $defaultBackupPath "$DBName-LogBackup-$(Get-Date -Format 'yyyyMMddHHmmss').trn"
        $logBackupQuery = "BACKUP LOG [$DBName] TO DISK = N'$logBackupFile' WITH INIT, STATS = 10"
        Invoke-Sqlcmd -ServerInstance $PrimarySQLName -Query $logBackupQuery -ErrorAction Stop
        Write-Log -Message "LOG backup created at $logBackupFile."
    }
    catch {
        Write-Log -Message "LOG backup failed (may still be OK if no log changes yet): $($_.Exception.Message)"
        # do not throw
    }
}

######################################################################
# Keep your existing Ensure-AlwaysOnExists and Create-Listener
######################################################################
function Ensure-AlwaysOnExists {
    param (
        [string]$AGName,
        [string]$PrimaryServer,
        [string]$SecondaryServer,
        [string]$DatabaseName,
        [string]$SQLAccount
    )
    try {
        # Check if AG exists
        $agCheck = Invoke-Sqlcmd -ServerInstance $PrimaryServer -Query "
SELECT name FROM sys.availability_groups WHERE name = '$AGName'"
        if ($agCheck) {
            Write-Log -Message "Availability Group '$AGName' already exists on $PrimaryServer"
            return
        }

        Write-Log -Message "Creating Basic AG '$AGName' on $PrimaryServer..."

        # Create endpoints if not already created
        $endpointQuery = "IF NOT EXISTS (SELECT * FROM sys.endpoints WHERE name = 'Hadr_endpoint')
CREATE ENDPOINT [Hadr_endpoint]
STATE=STARTED
AS TCP (LISTENER_PORT = 5022)
FOR DATA_MIRRORING (ROLE=ALL, AUTHENTICATION=WINDOWS, ENCRYPTION=REQUIRED ALGORITHM AES)"
        Invoke-Sqlcmd -ServerInstance $PrimaryServer -Query $endpointQuery

        # Wait for secondary SQL Server to be accessible
        $maxRetries = 30
        $retryInterval = 20
        $connected = $false
        for ($i = 1; $i -le $maxRetries; $i++) {
            try {
                Invoke-Sqlcmd -ServerInstance $SecondaryServer -Query "SELECT 1" -ErrorAction Stop | Out-Null
                $connected = $true
                Write-Log -Message "Secondary server [$SecondaryServer] is online."
                break
            }
            catch {
                Write-Log -Message "Waiting for [$SecondaryServer] to be ready... Attempt $i/$maxRetries"
                Start-Sleep -Seconds $retryInterval
            }
        }
        if (-not $connected) {
            throw "Secondary server [$SecondaryServer] did not become available in time."
        }
        Invoke-Sqlcmd -ServerInstance $SecondaryServer -Query $endpointQuery

        # Grant connect permissions
        $Qry1 = "IF NOT EXISTS ( SELECT name FROM sys.server_principals WHERE name = N'$SQLAccount')
BEGIN
 CREATE LOGIN [$SQLAccount] FROM WINDOWS;
 GRANT CONNECT ON ENDPOINT::[Hadr_endpoint] TO [$SQLAccount];
END"
        Invoke-Sqlcmd -ServerInstance $PrimaryServer -Query $Qry1
        Invoke-Sqlcmd -ServerInstance $SecondaryServer -Query $Qry1

        # Retry CREATE AG (handles transient 'replica manager waiting for WSFC')
        $agRetryMax = 30
        $agRetryDelay = 10
        for ($try = 1; $try -le $agRetryMax; $try++) {
            try {
                Write-Log -Message ("CREATE AG attempt {0}/{1}..." -f $try, $agRetryMax)
                Invoke-Sqlcmd -ServerInstance $PrimaryServer -Query "
CREATE AVAILABILITY GROUP [$AGName]
WITH (AUTOMATED_BACKUP_PREFERENCE = PRIMARY, DB_FAILOVER = ON)
FOR DATABASE [$DatabaseName]
REPLICA ON
N'$PrimaryServer' WITH (
 ENDPOINT_URL = 'TCP://$($PrimaryServer):5022',
 FAILOVER_MODE = AUTOMATIC,
 AVAILABILITY_MODE = SYNCHRONOUS_COMMIT,
 SEEDING_MODE = AUTOMATIC
),
N'$SecondaryServer' WITH (
 ENDPOINT_URL = 'TCP://$($SecondaryServer):5022',
 FAILOVER_MODE = AUTOMATIC,
 AVAILABILITY_MODE = SYNCHRONOUS_COMMIT,
 SEEDING_MODE = AUTOMATIC
);" -ErrorAction Stop 2>$null
                Write-Log -Message "Primary node AG creation completed."
                break
            }
            catch {
                Write-Log -Message ("CREATE AG failed attempt {0}/{1}: {2}" -f $try, $agRetryMax, $_.Exception.Message)
                if ($try -eq $agRetryMax) { throw }
                Start-Sleep -Seconds $agRetryDelay
            }
        }

        $secTcp = "tcp:{0},1433" -f $SecondaryServer
        Invoke-Sqlcmd -ServerInstance $secTcp -Query "
ALTER AVAILABILITY GROUP [$AGName] JOIN;
ALTER AVAILABILITY GROUP [$AGName] GRANT CREATE ANY DATABASE;
" -ErrorAction Stop
        Write-Log -Message "Secondary node JOIN completed"
        Write-Log -Message "Basic Availability Group '$AGName' created successfully."
    }
    catch {
        Write-Log -Message "Error creating AG: $($_.Exception.Message)"
        throw
    }
}

function Create-Listener {
    param (
        [Parameter(Mandatory=$true)][string]$PrimarySQL,
        [Parameter(Mandatory=$true)][string]$AGName,
        [Parameter(Mandatory=$true)][string]$ListenerName,
        [Parameter(Mandatory=$true)][string]$ListenerIP,
        [Parameter(Mandatory=$true)][string]$ListenerSM,
        [Parameter(Mandatory=$true)][int]$ListenerPort
    )
    $sql = @"
IF NOT EXISTS (
 SELECT 1
 FROM sys.availability_group_listeners
 WHERE [dns_name] = N'$ListenerName'
)
BEGIN
 RAISERROR('Creating listener $ListenerName...', 10, 1) WITH NOWAIT;
 ALTER AVAILABILITY GROUP [$AGName]
 ADD LISTENER N'$ListenerName' (
 WITH IP ((N'$ListenerIP', N'$ListenerSM')),
 PORT = $ListenerPort
 );
END
ELSE
BEGIN
 RAISERROR('Listener $ListenerName already exists', 10, 1) WITH NOWAIT;
END
"@
    # Wait SQL connectivity on primary
    $maxRetries = 60
    $retryInterval = 5
    for ($i = 1; $i -le $maxRetries; $i++) {
        try {
            Invoke-Sqlcmd -ServerInstance $PrimarySQL -Query "SELECT 1" -ErrorAction Stop | Out-Null
            break
        }
        catch {
            Write-Log -Message "Waiting for [$PrimarySQL] to be ready... Attempt $i/$maxRetries"
            Start-Sleep -Seconds $retryInterval
        }
    }
    Write-Log -Message "Executing listener creation SQL on [$PrimarySQL]..."
    $result = Invoke-Sqlcmd -ServerInstance $PrimarySQL -Query $sql -ErrorAction Stop
    if ($result) { $result | ForEach-Object { Write-Log -Message $_.Column1 } }
    else { Write-Log -Message "Listener creation completed with no result set." }
}

######################################################################
# Main execution on PRIMARY
######################################################################
# Local SQL sanity check
try {
    $SqlVersion = Invoke-Sqlcmd -Query "SELECT @@VERSION" -ServerInstance "localhost"
    Write-Log -Message "The Invoke-Sqlcmd worked!"
    Write-Log -Message "SQL Version: $(($SqlVersion.Column1 -split "`n")[0])"
}
catch {
    Write-Log -Message "The Invoke-Sqlcmd didn't work. Error: $($_.Exception.Message)"
}

# Ensure DB is ready (FULL + backups)
Ensure-Database -PrimarySQLName $PrimarySQLName -DBName $DBName

# Enable AlwaysOn locally on PRIMARY
Ensure-AlwaysOn-EnabledLocal -InstanceName "DEFAULT"

# Wait for secondary IsHadrEnabled=1 (secondary enables locally then exits)
$hadrOk = Wait-RemoteHadrEnabled -ServerInstance $SecondarySQLName -TimeoutSeconds 1800 -PollSeconds 10
if (-not $hadrOk) {
    Write-Log -Message ("ERROR: Secondary [{0}] did not report IsHadrEnabled=1 in time. Aborting." -f $SecondarySQLName)
    exit 1
}

# Create AG + listener
Ensure-AlwaysOnExists -AGName $AG_Name -PrimaryServer $PrimarySQLName -SecondaryServer $SecondarySQLName -DatabaseName $DBName -SQLAccount $SQLAccount
Write-Log -Message "Creating listener"
Create-Listener `
 -PrimarySQL $PrimarySQLName `
 -AGName $AG_Name `
 -ListenerName $ListenerName `
 -ListenerIP $ListenerIP `
 -ListenerSM $ListenerSM `
 -ListenerPort $ListenerPort

# NOTE: Original failover block referenced undefined variables and remains disabled intentionally.

Write-Log -Message "End of Install-Always-On.ps1 script attained."