function Write-Log {
    param (
        [string]$Message
    )

    # Ensure the log subfolder exists
    if (-not (Test-Path -Path $logSubFolder)) {
        New-Item -Path $logSubFolder -ItemType Directory -Force | Out-Null
    }

    # Get the name of the calling script (not full path)
    $callerScript = Split-Path -Path $MyInvocation.ScriptName -Leaf

    # Create timestamped log entry with script name
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $entry = "$timestamp [$callerScript] - $Message"

    # Write to log file
    Add-Content -Path $logFilePath -Value $entry
}

