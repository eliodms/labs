﻿<#
.SYNOPSIS
  First-boot configuration for SCVMM-deployed servers.

.DESCRIPTION
  - Adds the specified domain user to local Administrators
  - Grants SeInteractiveLogonRight (Allow log on locally)
  - Grants SeBatchLogonRight (Allow log on as a batch job)
  - Safe to rerun (idempotent), preserves existing principals
  - Writes a log to C:\Windows\Temp\FirstBoot.log

.PARAMETER DomainUser
  The DOMAIN\User (or user@domain) to grant rights to.

.PARAMETER LogPath
  Path to the log file.

.NOTES
  Runs best as LocalSystem (e.g., from GuiRunOnce). Local policy may be overridden by GPO later.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)]
    [string]$DomainUser = 'CORP\User01',

    [Parameter(Mandatory=$false)]
    [string]$LogPath = 'C:\Windows\Temp\FirstBoot.log'
)

# ----------------------------- Logging & helpers -----------------------------
function Write-Log {
    param(
        [Parameter(Mandatory=$true)][string]$Message,
        [ValidateSet('INFO','WARN','ERROR')] [string]$Level = 'INFO'
    )
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff')
    $line = "[${ts}] [$Level] $Message"
    Add-Content -Path $LogPath -Value $line
    if ($Level -eq 'ERROR') { Write-Error $Message } else { Write-Host $line }
}

function Test-IsLocalSystem {
    try { [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value -eq 'S-1-5-18' }
    catch { $false }
}

# ----------------------------- LSA interop (no secedit) ----------------------
$lsaCode = @"
using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct LSA_UNICODE_STRING {
    public UInt16 Length;
    public UInt16 MaximumLength;
    public IntPtr Buffer;
}

[StructLayout(LayoutKind.Sequential)]
public struct LSA_OBJECT_ATTRIBUTES {
    public UInt32 Length;
    public IntPtr RootDirectory;
    public IntPtr ObjectName;   // PLSA_UNICODE_STRING
    public UInt32 Attributes;
    public IntPtr SecurityDescriptor;        // PSECURITY_DESCRIPTOR
    public IntPtr SecurityQualityOfService;  // PSECURITY_QUALITY_OF_SERVICE
}

public static class LsaNative {
    [DllImport("advapi32.dll", SetLastError=true)]
    public static extern UInt32 LsaOpenPolicy(
        IntPtr SystemName,
        ref LSA_OBJECT_ATTRIBUTES ObjectAttributes,
        UInt32 DesiredAccess,
        out IntPtr PolicyHandle);

    [DllImport("advapi32.dll")]
    public static extern UInt32 LsaClose(IntPtr PolicyHandle);

    [DllImport("advapi32.dll")]
    public static extern UInt32 LsaNtStatusToWinError(UInt32 status);

    [DllImport("advapi32.dll", SetLastError=true)]
    public static extern UInt32 LsaAddAccountRights(
        IntPtr PolicyHandle,
        IntPtr AccountSid,
        LSA_UNICODE_STRING[] UserRights,
        UInt32 CountOfRights);

    public const UInt32 POLICY_LOOKUP_NAMES   = 0x00000800;
    public const UInt32 POLICY_CREATE_ACCOUNT = 0x00000010;

    public static LSA_UNICODE_STRING InitLsaString(string s) {
        if (s == null) throw new ArgumentNullException("s");
        LSA_UNICODE_STRING lus = new LSA_UNICODE_STRING();
        lus.Buffer = Marshal.StringToHGlobalUni(s);
        lus.Length = (UInt16)(s.Length * 2);
        lus.MaximumLength = (UInt16)(lus.Length + 2);
        return lus;
    }
}
"@
Add-Type -TypeDefinition $lsaCode -ErrorAction Stop

function Grant-LogonRights {
    param(
        [Parameter(Mandatory=$true)][byte[]]$SidBytes,
        [Parameter(Mandatory=$true)][string[]]$Rights
    )

    $attrs = New-Object LSA_OBJECT_ATTRIBUTES
    $attrs.Length = [System.Runtime.InteropServices.Marshal]::SizeOf([Type][LSA_OBJECT_ATTRIBUTES])

    $POLICY_ACCESS = [LsaNative]::POLICY_LOOKUP_NAMES -bor [LsaNative]::POLICY_CREATE_ACCOUNT
    $policy = [IntPtr]::Zero
    $status = [LsaNative]::LsaOpenPolicy([IntPtr]::Zero, [ref]$attrs, $POLICY_ACCESS, [ref]$policy)
    if ($status -ne 0) {
        $winErr = [LsaNative]::LsaNtStatusToWinError($status)
        throw "LsaOpenPolicy failed: WinError=$winErr"
    }

    try {
        $sidPtr = [Runtime.InteropServices.Marshal]::AllocHGlobal($SidBytes.Length)
        [Runtime.InteropServices.Marshal]::Copy($SidBytes, 0, $sidPtr, $SidBytes.Length)

        $lus = @()
        foreach ($r in $Rights) { $lus += [LsaNative]::InitLsaString($r) }

        $status = [LsaNative]::LsaAddAccountRights($policy, $sidPtr, $lus, [uint32]$lus.Length)
        if ($status -ne 0) {
            $winErr = [LsaNative]::LsaNtStatusToWinError($status)
            throw "LsaAddAccountRights failed: WinError=$winErr"
        }
    }
    finally {
        if ($policy -ne [IntPtr]::Zero) { [void][LsaNative]::LsaClose($policy) }
    }
}

# ----------------------------- Main ------------------------------------------
$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Path (Split-Path $LogPath) -Force | Out-Null
Write-Log "Starting FirstBoot.ps1 as $([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)"
if (-not (Test-IsLocalSystem)) { Write-Log "Warning: Not running as LocalSystem. Some actions may fail." -Level WARN }

try {
    # Normalize UPN -> DOMAIN\User if needed (best-effort)
    if ($DomainUser -notmatch '\\' -and $DomainUser -match '@') {
        try {
            $ctx = New-Object System.DirectoryServices.AccountManagement.PrincipalContext('Domain')
            $usr = [System.DirectoryServices.AccountManagement.UserPrincipal]::FindByIdentity($ctx, $DomainUser)
            if ($usr) {
                $DomainUser = "$($usr.Context.Name)\$($usr.SamAccountName)"
                Write-Log "Resolved UPN to down-level name: $DomainUser"
            }
        } catch {
            Write-Log "UPN resolve failed; using provided identity: $DomainUser" -Level WARN
        }
    }

    # 1) Ensure local Administrators membership
    try {
        Add-LocalGroupMember -Group 'Administrators' -Member $DomainUser -ErrorAction Stop
        Write-Log "Added '$DomainUser' to local Administrators."
    } catch {
        if ($_.Exception.Message -match 'already a member') {
            Write-Log "'$DomainUser' already in Administrators (ok)."
        } else { throw }
    }

    # 2) Resolve SID and grant rights via LSA (reliable during setup)
    $nt = New-Object System.Security.Principal.NTAccount($DomainUser)
    $sid = $nt.Translate([System.Security.Principal.SecurityIdentifier])
    $sidBytes = New-Object 'byte[]' ($sid.BinaryLength)
    $sid.GetBinaryForm($sidBytes, 0)

    $rights = @('SeInteractiveLogonRight','SeBatchLogonRight')
    Write-Log "Granting via LSA: $($rights -join ', ') to $DomainUser"
    Grant-LogonRights -SidBytes $sidBytes -Rights $rights
    Write-Log "LSA rights granted successfully."

    # 3) Best-effort policy refresh (GPO may still override later)
    try { gpupdate /target:computer /force | Out-Null; Write-Log "Group policy refreshed." }
    catch { Write-Log "gpupdate failed (continuing): $($_.Exception.Message)" -Level WARN }

    Write-Log "FirstBoot.ps1 completed successfully."
    exit 0
}
catch {
    Write-Log "ERROR: $($_.Exception.Message)" -Level ERROR
    exit 1 }
