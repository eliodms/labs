
# Variables
$ScriptDir = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
. (Join-Path $ScriptDir "Functions.ps1")

Start-Transcript -Path "$ScriptDir\$Env:COMPUTERNAME.log"

$SetupExe = "\\fs01.corp.demolab.com\Share\Sources\SQL-2022\setup.exe"
$ConfigFile = Join-Path $ScriptDir "SQLServer2022_Config.ini"

# Define variables before the function
$logdir = "\\fs01\VMMlibrary\Logs"
$HostName = $env:COMPUTERNAME
$timestampFolder = Get-Date -Format "yyyyMMdd" # Add "-HHmmss" for mre detail
$logSubFolder = Join-Path -Path $logdir -ChildPath "$HostName-$timestampFolder"
$logFilePath = Join-Path -Path $logSubFolder -ChildPath "Install-SQL.log"

$RedirectSQLStandardOutput = Join-Path -Path $logSubFolder -ChildPath "SQLStandardOutput.log"
$RedirectSQLStandardError = Join-Path -Path $logSubFolder -ChildPath "SQLStandardError.log"

# Path to the CSV file
$CsvPath = Join-Path $ScriptDir "ListOfSQLServers.csv"

###################################################
# Run AssignLetters.ps1 and wait for it to finish #
###################################################
Write-Log -Message "Calling Assign-Letters.ps1"
$AssignScript = Join-Path $ScriptDir "Assign-Letters.ps1"
& $AssignScript

###################################################
# Install SQL Core                                #
###################################################
Write-Log -Message "Calling Install-SQL-Core.ps1"
$AssignScript = Join-Path $ScriptDir "Install-SQL-Core.ps1"
& $AssignScript

###################################################
# Install SQL always ON                           #
###################################################
Write-Log -Message "Calling Install-Always-On.ps1"

# Import CSV and find matching record
$ServerRecord = Import-Csv -Path $CsvPath | Where-Object { $PSItem.ComputerName -eq $HostName }

if ($null -eq $ServerRecord) {
    Write-Log -Message "No matching record found for $HostName in $CsvPath. Exiting..."
    exit 1
}

# Path to the Always-On script
$AssignScript = Join-Path $ScriptDir "Install-Always-On.ps1"

# Call the script with parameters from CSV
& $AssignScript `
    -WSFC_Name $ServerRecord.WSFC_Name `
    -WSFC_IP $ServerRecord.WSFC_IP `
    -PrimarySQLName $ServerRecord.PrimarySQLName `
    -SecondarySQLName $ServerRecord.SecondarySQLName `
    -DBName $ServerRecord.DBName `
    -BackupPath $ServerRecord.BackupPath `
    -AG_Name $ServerRecord.AG_Name `
    -ListenerName $ServerRecord.ListenerName `
    -ListenerIP $ServerRecord.ListenerIP `
    -ListenerSM $ServerRecord.ListenerSM `
    -ListenerPort $ServerRecord.ListenerPort

Write-Log -Message "End of Install-SQL.ps1 script attained."

Stop-Transcript
