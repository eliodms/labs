﻿###################################################
# This script is called by Install-SQL.ps1 script #
###################################################

param (
    [Parameter(Mandatory = $true)]
    [string]$WSFC_Name,

    [Parameter(Mandatory = $true)]
    [string]$WSFC_IP,

    [Parameter(Mandatory = $true)]
    [string]$PrimarySQLName,

    [Parameter(Mandatory = $true)]
    [string]$SecondarySQLName,

    [Parameter(Mandatory = $true)]
    [string]$DBName,

    [Parameter(Mandatory = $true)]
    [string]$BackupPath,

    [Parameter(Mandatory = $true)]
    [string]$AG_Name,

    [Parameter(Mandatory = $true)]
    [string]$ListenerName,
    
    [Parameter(Mandatory = $true)]
    [string]$ListenerIP,

    [Parameter(Mandatory = $true)]
    [string]$ListenerSM,

    [Parameter(Mandatory = $true)]
    [string]$ListenerPort
)

# Load functions
$ScriptDir = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
. (Join-Path $ScriptDir "Functions.ps1")

# The SQL module installed together with SQL is added to $env:PSModulePath but is not visible before a reboot
# Hence, we need to call it as shown below
# Adjust below path as required
Import-Module "C:\Program Files (x86)\Microsoft SQL Server\160\Tools\PowerShell\Modules\SQLPS\SQLPS.psd1" -DisableNameChecking

# Enable firewall rule for SQL
# Check if an enabled inbound rule already exists for the port and protocol
$ports = @(1433, 1434, 5022, 135)
foreach($port in $ports)
{
    $ruleExists = Get-NetFirewallRule -Enabled True -Direction Inbound |
        Where-Object {
            ($_ | Get-NetFirewallPortFilter).LocalPort -contains $Port -and
            ($_ | Get-NetFirewallPortFilter).Protocol -eq "TCP"     }
    if ($ruleExists) {
            Write-Log -Message "Port $Port ($Protocol) is already allowed in the firewall."
        } else {
            Write-Log -Message "Port $Port ($Protocol) is not open. Creating inbound rule..."
            New-NetFirewallRule -DisplayName "Allow SQL Port $port" -Direction Inbound -LocalPort $port -Protocol TCP -Action Allow
            Write-Log -Message "Inbound rule created. Port $Port ($Protocol) is now open."
        }
}

##########################################################################
# Only $PrimarySQLName should create the cluster and configure Always On #
# Let's make sure we are $PrimarySQLName, if not we will exit the script #                                                                                       #
##########################################################################

if ($Env:COMPUTERNAME -ne $PrimarySQLName) 
{ 
    Write-Log -Message "This node ($Env:COMPUTERNAME) is not the primary SQL node."
    Write-Log -Message "The primary node ($PrimarySQLName) will proceed with cluster creation. Exiting..."
    exit
}

###################################################################
# If we reach this point, it means that we are on $PrimarySQLName #
###################################################################
# Continue with the rest of the script here
Write-Log -Message "This is the primary SQL node. Proceeding with cluster creation and Always On configuration..."

$nodes = @($PrimarySQLName, $SecondarySQLName)

# Create the cluster and add nodes if not already present
if (-not (Get-Cluster -Name $WSFC_Name -ErrorAction SilentlyContinue)) {
    Write-Log -Message "WSFC cluster $WSFC_Name does not exist, let's create it."
    New-Cluster -Name $WSFC_Name -Node $PrimarySQLName, $SecondarySQLName -StaticAddress $WSFC_IP -NoStorage
    Write-Log -Message "WSFC cluster $WSFC_Name is created"}
    else{
    Write-Log -Message "WSFC cluster $WSFC_Name is already installed"
}

function Ensure-Database {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]$PrimarySQLName,

        [Parameter(Mandatory=$true)]
        [string]$DBName  )

    Write-Log -Message "Fetching default backup path from SQL Server..."

    $defaultBackupPathQuery = @"
    DECLARE @BackupPath NVARCHAR(512)
    EXEC master.dbo.xp_instance_regread
        N'HKEY_LOCAL_MACHINE',
        N'Software\Microsoft\MSSQLServer\MSSQLServer',
        N'BackupDirectory',
        @BackupPath OUTPUT,
        'no_output'
    SELECT @BackupPath AS BackupPath
"@

    try {
        $backupPathResult = Invoke-Sqlcmd -ServerInstance $PrimarySQLName -Query $defaultBackupPathQuery -ErrorAction Stop
    }
    catch {
        Write-Log -Message "Failed to retrieve default backup path from SQL Server: $_"
        return
    }

    $defaultBackupPath = $backupPathResult.BackupPath

    if ([string]::IsNullOrEmpty($defaultBackupPath)) {
        Write-Log -Message "Could not retrieve default backup path from SQL Server. Please specify a backup path."
        return
    }

    Write-Log -Message "Using default backup path: $defaultBackupPath"

    # Check if database exists
    $dbExistsQuery = "SELECT COUNT(*) AS DBCount FROM sys.databases WHERE name = '$DBName'"

    try {
        $dbExistsResult = Invoke-Sqlcmd -ServerInstance $PrimarySQLName -Query $dbExistsQuery -ErrorAction Stop
    }
    catch {
        Write-Log -Message "Failed to check database existence: $_"
        return
    }

    $dbExists = $dbExistsResult.DBCount -gt 0

    if (-not $dbExists) {
        Write-Log -Message "Database '$DBName' does not exist on $PrimarySQLName. Creating database..."

        $createDbQuery = "CREATE DATABASE [$DBName]"
        Invoke-Sqlcmd -ServerInstance $PrimarySQLName -Query $createDbQuery

        Write-Log -Message "Database '$DBName' created."
    }
    else {
        Write-Log -Message "Database '$DBName' exists on $PrimarySQLName."
    }

    # Check recovery model
    $recoveryModelQuery = "SELECT recovery_model_desc FROM sys.databases WHERE name = '$DBName'"

    try {
        $recoveryModelResult = Invoke-Sqlcmd -ServerInstance $PrimarySQLName -Query $recoveryModelQuery -ErrorAction Stop
    }
    catch {
        Write-Log -Message "Failed to get recovery model: $_"
        return
    }

    $recoveryModel = $recoveryModelResult.recovery_model_desc

    if ($recoveryModel -ne "FULL") {
        Write-Log -Message "Recovery model for '$DBName' is '$recoveryModel'. Changing to FULL..."

        $setRecoveryModelQuery = "ALTER DATABASE [$DBName] SET RECOVERY FULL"
        Invoke-Sqlcmd -ServerInstance $PrimarySQLName -Query $setRecoveryModelQuery

        Write-Log -Message "Recovery model changed to FULL for '$DBName'."
    }
    else {
        Write-Log -Message "Recovery model for '$DBName' is already FULL."
    }

    # Check for recent backup (last 1 day)
    $backupCheckQuery = @"
    SELECT TOP 1 backup_finish_date
    FROM msdb.dbo.backupset
    WHERE database_name = '$DBName' AND type = 'D' -- Full backup
    ORDER BY backup_finish_date DESC
"@

    try {
        $backupResult = Invoke-Sqlcmd -ServerInstance $PrimarySQLName -Query $backupCheckQuery -ErrorAction Stop
    }
    catch {
        Write-Log -Message "Failed to check backups: $_"
        return
    }

    $backupExists = $false
    if ($backupResult) {
        $lastBackupDate = $backupResult.backup_finish_date
        $timeSinceBackup = (Get-Date) - $lastBackupDate
        if ($timeSinceBackup.TotalDays -lt 1) {
            $backupExists = $true
        }
    }

    if (-not $backupExists) {
        Write-Log -Message "No recent full backup found for '$DBName'. Creating backup..."

        $backupFile = Join-Path $defaultBackupPath "$DBName-FullBackup-$(Get-Date -Format 'yyyyMMddHHmmss').bak"
        $backupQuery = "BACKUP DATABASE [$DBName] TO DISK = N'$backupFile' WITH INIT, STATS = 10"

        try {
            Invoke-Sqlcmd -ServerInstance $PrimarySQLName -Query $backupQuery -ErrorAction Stop
            Write-Log -Message "Backup created at $backupFile."
        }
        catch {
            Write-Log -Message "Backup failed: $_"
        }
    }
    else {
        Write-Log -Message "Recent full backup found for '$DBName' on $lastBackupDate."
    }
}

function Ensure-AlwaysOn-Enabled {
    param (
        [string]$NodeName,
        [string]$InstanceName = "DEFAULT"
    )

    $serverInstance = if ($InstanceName -eq "DEFAULT") { "$NodeName" } else { "$NodeName\$InstanceName" }
    $serverPath = "SQLSERVER:\SQL\$NodeName\$InstanceName"

    try {
        # Wait for SQL connectivity before proceeding
        $maxRetries = 30
        $retryInterval = 60
        $connected = $false

        for ($i = 1; $i -le $maxRetries; $i++) {
            try {
                Invoke-Sqlcmd -ServerInstance $serverInstance -Query "SELECT 1" -ErrorAction Stop
                $connected = $true
                Write-Log -Message "[$serverInstance] is online."
                break
            } catch {
                Write-Log -Message "Waiting for [$serverInstance] to be ready... Attempt $i/$maxRetries"
                Start-Sleep -Seconds $retryInterval
            }
        }

        if (-not $connected) {
            Write-Log -Message "[$serverInstance] did not become available after $($maxRetries * $retryInterval) seconds."
            throw "[$serverInstance] did not become available after $($maxRetries * $retryInterval) seconds."        
            }

        # Check if Always On is enabled
        $result = Invoke-Sqlcmd -ServerInstance $serverInstance -Query "SELECT SERVERPROPERTY('IsHadrEnabled') AS IsHadrEnabled"

        if ($result.IsHadrEnabled -eq 1) {
            Write-Log -Message "Always On is already ENABLED on $serverInstance"
        } else {
            Write-Log -Message "Enabling Always On for $serverInstance..."

            # Enable Always On
            Enable-SqlAlwaysOn -Path $serverPath -Force

            Write-Log -Message "Always On has been ENABLED on $serverInstance. Restarting SQL Service..."

            # Restart SQL Server service remotely
            $serviceName = if ($InstanceName -eq "DEFAULT") { "MSSQLSERVER" } else { "MSSQL`$$InstanceName" }
            Invoke-Command -ComputerName $NodeName -ScriptBlock {
                param ($svc)
                Restart-Service -Name $svc -Force
            } -ArgumentList $serviceName

            Write-Log -Message "SQL Server service restarted on $NodeName"
        }
    }
    catch {
        Write-Log -Message "Error on $serverInstance : $_"
    }
}

function Ensure-AlwaysOnExists {
    param (
        [string]$AGName,
        [string]$PrimaryServer,
        [string]$SecondaryServer,
        [string]$DatabaseName,
        [string]$SQLAccount
    )

    try {
        # Check if AG exists
        $agCheck = Invoke-Sqlcmd -ServerInstance $PrimaryServer -Query "
            SELECT name FROM sys.availability_groups WHERE name = '$AGName'"
       
        if ($agCheck) {
            Write-Log -Message "Availability Group '$AGName' already exists on $PrimaryServer"
            return
        }

        Write-Log -Message "Creating Basic AG '$AGName' on $PrimaryServer..."

        # Create endpoints if not already created
        $endpointQuery = "IF NOT EXISTS (SELECT * FROM sys.endpoints WHERE name = 'Hadr_endpoint')
            CREATE ENDPOINT [Hadr_endpoint]
            STATE=STARTED
            AS TCP (LISTENER_PORT = 5022)
            FOR DATA_MIRRORING (ROLE=ALL, AUTHENTICATION=WINDOWS, ENCRYPTION=REQUIRED ALGORITHM AES)"
       
        Invoke-Sqlcmd -ServerInstance $PrimaryServer -Query $endpointQuery

        # Wait for secondary SQL Server to be accessible (it is currently deploying)
        $maxRetries = 15
        $retryInterval = 60 # seconds
        $connected = $false
        
        for ($i = 1; $i -le $maxRetries; $i++) {
            try {
                Invoke-Sqlcmd -ServerInstance $SecondaryServer -Query "SELECT 1" -ErrorAction Stop
                $connected = $true
                Write-Log -Message "Secondary server [$SecondaryServer] is online."
                break
            } catch {
                Write-Log -Message "Waiting for [$SecondaryServer] to be ready... Attempt $i/$maxRetries"
                Start-Sleep -Seconds $retryInterval
            }
        }
        
        if (-not $connected) {
            Write-Log -Message "Secondary server [$SecondaryServer] did not become available after $($maxRetries * $retryInterval) seconds."
        }
        
        # Now run the endpoint creation query
        Invoke-Sqlcmd -ServerInstance $SecondaryServer -Query $endpointQuery

        # Grant connect permissions to each other
        $Qry1="IF NOT EXISTS ( SELECT name FROM sys.server_principals WHERE name = N'$SQLAccount')
            BEGIN
              CREATE LOGIN [$SQLAccount] FROM WINDOWS;
              GRANT CONNECT ON ENDPOINT::[Hadr_endpoint] TO [$SQLAccount];
        END"

        #Invoke-Sqlcmd -ServerInstance $PrimaryServer -Query "GRANT CONNECT ON ENDPOINT::Hadr_endpoint TO [$SQLAccount]"
        #Invoke-Sqlcmd -ServerInstance $SecondaryServer -Query "GRANT CONNECT ON ENDPOINT::Hadr_endpoint TO [$SQLAccount]"
        Invoke-Sqlcmd -ServerInstance $PrimaryServer -Query $Qry1
        Invoke-Sqlcmd -ServerInstance $SecondaryServer -Query $Qry1

        # Create AG
                
        # # Detect SQL Server Edition
        # $editionQuery = "SELECT SERVERPROPERTY('Edition') AS Edition"
        # $edition = Invoke-Sqlcmd -ServerInstance $PrimaryServer -Query $editionQuery | Select-Object -ExpandProperty Edition
        # $edition
        
        Invoke-Sqlcmd -ServerInstance $PrimaryServer -Query "
            CREATE AVAILABILITY GROUP [$AGName]
            WITH (AUTOMATED_BACKUP_PREFERENCE = PRIMARY,
                  DB_FAILOVER = ON)
            FOR DATABASE [$DatabaseName]
            REPLICA ON
                N'$PrimaryServer' WITH (
                    ENDPOINT_URL = 'TCP://$($PrimaryServer):5022',
                    FAILOVER_MODE = AUTOMATIC,
                    AVAILABILITY_MODE = SYNCHRONOUS_COMMIT,
                    SEEDING_MODE = AUTOMATIC
                ),
                N'$SecondaryServer' WITH (
                    ENDPOINT_URL = 'TCP://$($SecondaryServer):5022',
                    FAILOVER_MODE = AUTOMATIC,
                    AVAILABILITY_MODE = SYNCHRONOUS_COMMIT,
                    SEEDING_MODE = AUTOMATIC
                );"

        Write-Log -Message "Primary node creation completed"
        Invoke-Sqlcmd -ServerInstance $SecondaryServer -Query "
            ALTER AVAILABILITY GROUP [$AGName] JOIN;
            ALTER AVAILABILITY GROUP [$AGName] GRANT CREATE ANY DATABASE;
            "
        Write-Log -Message "Secondary node JOIN completed"
        Write-Log -Message "Basic Availability Group '$AGName' created successfully."
    }
    catch {
        Write-Log -Message "Error creating AG: $_"
    }
}

function Create-Listener {

    param (
        [Parameter(Mandatory=$true)][string]$PrimarySQL,
        [Parameter(Mandatory=$true)][string]$AGName,
        [Parameter(Mandatory=$true)][string]$ListenerName,
        [Parameter(Mandatory=$true)][string]$ListenerIP,
        [Parameter(Mandatory=$true)][string]$ListenerSM,
        [Parameter(Mandatory=$true)][int]$ListenerPort
    )

    # Build the SQL query
    $sql = @"
IF NOT EXISTS (
    SELECT 1
    FROM sys.availability_group_listeners
    WHERE [dns_name] = N'$ListenerName'
)
BEGIN
    RAISERROR('Creating listener $ListenerName...', 10, 1) WITH NOWAIT;
    ALTER AVAILABILITY GROUP [$AGName]
    ADD LISTENER N'$ListenerName' (
        WITH IP ((N'$ListenerIP', N'$ListenerSM')),
        PORT = $ListenerPort
    );
END
ELSE
BEGIN
    RAISERROR('Listener $ListenerName already exists', 10, 1) WITH NOWAIT;
END
"@

    try {
        # Step 1: Wait for SQL connectivity
        $maxRetries = 30
        $retryInterval = 10
        $connected = $false

        for ($i = 1; $i -le $maxRetries; $i++) {
            try {
                Invoke-Sqlcmd -ServerInstance $PrimarySQL -Query "SELECT 1" -ErrorAction Stop
                $connected = $true
                Write-Log -Message "[$PrimarySQL] is online."
                break
            } catch {
                Write-Log -Message "Waiting for [$PrimarySQL] to be ready... Attempt $i/$maxRetries"
                Start-Sleep -Seconds $retryInterval
            }
        }

        if (-not $connected) {
            Write-Log -Message "[$PrimarySQL] did not become available after $($maxRetries * $retryInterval) seconds."
            throw "SQL connectivity failed for [$PrimarySQL]"
        }

        # Step 2: Execute the listener creation query
        Write-Log -Message "Executing listener creation SQL on [$PrimarySQL]..."
        $result = Invoke-Sqlcmd -ServerInstance $PrimarySQL -Query $sql -ErrorAction Stop

        # Step 3: Log results
        if ($result) {
            $result | ForEach-Object { Write-Log -Message $_.Column1 }
        } else {
            Write-Log -Message "Listener creation completed with no result set."
        }
    }
    catch {
        Write-Log -Message "Error executing SQL on [$PrimarySQL]: $_"
        throw
    }
}

# Check if SqlServer module is working correctly
try {
    $SqlVersion = Invoke-Sqlcmd -Query "SELECT @@VERSION" -ServerInstance "localhost"
    Write-Log -Message "The Invoke-Sqlcmd worked!"
    Write-Log -Message "SQL Version: $(($SqlVersion.Column1 -split "`n")[0])"
} catch {
    Write-Log -Message "The Invoke-Sqlcmd didn't work. Error: $($_.Exception.Message)"
}


Ensure-Database -PrimarySQLName $PrimarySQLName -DBName $DBName

Ensure-AlwaysOn-Enabled -NodeName $PrimarySQLName 
Ensure-AlwaysOn-Enabled -NodeName $SecondarySQLName

Ensure-AlwaysOnExists -AGName $AG_Name -PrimaryServer $PrimarySQLName -SecondaryServer $SecondarySQLName -DatabaseName $DBName -SQLAccount "CORP\administrator"

Create-Listener `
    -PrimarySQL $PrimarySQLName `
    -AGName $AG_Name `
    -ListenerName $ListenerName `
    -ListenerIP $ListenerIP `
    -ListenerSM $ListenerSM `
    -ListenerPort $ListenerPort

#make Failback script # Initiate failover
try {
    $ag = $server.AvailabilityGroups[$AvailabilityGroup]
    if ($ag -ne $null) {
       Write-Log -Message "Failing over Availability Group '$AvailabilityGroup' to '$NewPrimaryReplica'..."
       $ag.Failover()
       Write-Log -Message "Failover complete."
   } else {
      Write-Log -Message "Availability Group '$AvailabilityGroup' not found on '$NewPrimaryReplica'."
  }
} catch {
    Write-Log -Message "Failover failed: $_"
}

Write-Log -Message "End of Install-Always-On.ps1 script attained."
